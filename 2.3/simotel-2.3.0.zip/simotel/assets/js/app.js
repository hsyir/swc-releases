//vendors
require("../vendor/notify.min");


// -----------------
require("./components/loadStyleSheets");
require("./components/pusher");
require("./components/clickToDial");
require("./components/formsScripts");
require("./components/cookies");
