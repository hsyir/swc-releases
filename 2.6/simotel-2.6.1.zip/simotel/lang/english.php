<?php
/**
 * Sample addon module language file.
 * Language: English
 */
$_ADDONLANG['variable_name'] = "Translated language string.";
